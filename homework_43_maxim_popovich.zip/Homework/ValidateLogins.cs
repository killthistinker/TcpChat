﻿using System;
using System.Collections.Generic;

namespace Homework
{
    public class ValidateLogins 
    {
        public void ValidateLogin(Client icomingUser, List<Client> clients)
        {
            foreach (var client in clients)
            {
                if (client.UserName == icomingUser.UserName)
                {
                    Console.WriteLine($"Пользователь с именем {client.UserName} есть в сети");
                    Console.WriteLine($"Введите другое имя пользователя");
                }
                
            }
        }
    }
}